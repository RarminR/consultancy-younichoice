<?php
    function getStatusColor($status) {
        $status = trim($status);
        if ($status == "In progress")
            $colorStatus = "#FFA500";
        else if ($status == "Accepted")
            $colorStatus = "#008000";
        else if ($status == "Rejected")
            $colorStatus = "#FF0000";
        else if ($status == "Waitlisted")
            $colorStatus = "#808080";

        return $colorStatus;
    }

    session_start();
    require_once "configDatabase.php";

    if (!isset($_SESSION['type'])) { // testez daca userul est logat
        header("location: index.php");
        die();
    }
    else {
        $typeAccount = $_SESSION["type"];
        $accountId = $_SESSION["id"];
    }

    if (isset($_GET['studentId'])) // testez daca e setat un student
        $studentId = $_GET['studentId'];
    else {
        header("location: index.php");
        die();
    }

    $sqlStudentData = "SELECT * FROM studentData WHERE `studentId` = " .$studentId;
    
    $queryStudentData = mysqli_query($link, $sqlStudentData);

    if (mysqli_num_rows($queryStudentData) > 0) // testez daca exista vreun student cu id-ul dat
        $dataStudent = mysqli_fetch_assoc($queryStudentData);
    else {
        header("location: index.php");
        die();
    }

    if (!($dataStudent['consultantId'] == $accountId || $typeAccount == 1)) { // testez daca are acces userul la studentul dat
        header("location: index.php");
        die();
    }


    // for Universities
    $sqlApplicationsData = "SELECT *
    FROM applicationStatus AS a
    JOIN universities AS u
    ON a.universityId = u.universityId
    WHERE a.studentId = '$studentId' AND u.institutionType = 0;";
    $queryApplicationsData = mysqli_query($link, $sqlApplicationsData);

    $nUniversities = 0;
    while ($row = mysqli_fetch_assoc($queryApplicationsData)) {
        $universityId = $row["universityId"];
        $sqlUniversityName = "SELECT * FROM universities WHERE `universityId` = '$universityId'";
        $queryUniversityName = mysqli_query($link, $sqlUniversityName);
        // echo mysqli_num_rows($queryUniversityName);
        if (mysqli_num_rows($queryUniversityName) > 0) {
            $rowUniversityInfo = mysqli_fetch_assoc($queryUniversityName);
            $arrUniversityName[$nUniversities] = $rowUniversityInfo["universityName"];
            $arrUniversityCountry[$nUniversities] = $rowUniversityInfo["universityCountry"];
            $arrUniversityAppId[$nUniversities] = $row["applicationId"];
            $arrUniversityAppStatus[$nUniversities] = $row["appStatus"];
            $arrUniversityComission[$nUniversities] = $rowUniversityInfo["commission"];
            $arrUniversityScholarship[$nUniversities] = $row["scholarship"] . "$";

            $nUniversities++;
        }
    }


    // for Summer Schools
    $sqlApplicationsData = "SELECT *
    FROM applicationStatus AS a
    JOIN universities AS u
    ON a.universityId = u.universityId
    WHERE a.studentId = '$studentId' AND u.institutionType = 1;";
    $queryApplicationsData = mysqli_query($link, $sqlApplicationsData);

    $nSummer = 0;
    while ($row = mysqli_fetch_assoc($queryApplicationsData)) {
        $universityId = $row["universityId"];
        $sqlUniversityName = "SELECT * FROM universities WHERE `universityId` = '$universityId'";
        $queryUniversityName = mysqli_query($link, $sqlUniversityName);

        if (mysqli_num_rows($queryUniversityName) > 0) {
            $rowUniversityInfo = mysqli_fetch_assoc($queryUniversityName);
            $arrSummerName[$nSummer] = $rowUniversityInfo["universityName"];
            $arrSummerCountry[$nSummer] = $rowUniversityInfo["universityCountry"];
            $arrSummerAppId[$nSummer] = $row["applicationId"];
            $arrSummerAppStatus[$nSummer] = $row["appStatus"];
            $arrSummerComission[$nSummer] = $rowUniversityInfo["commission"];

            $nSummer++;
        }
    }

    // for Boarding Schools
    $sqlApplicationsData = "SELECT *
    FROM applicationStatus AS a
    JOIN universities AS u
    ON a.universityId = u.universityId
    WHERE a.studentId = '$studentId' AND u.institutionType = 2;";
    $queryApplicationsData = mysqli_query($link, $sqlApplicationsData);

    $nBoarding = 0;
    while ($row = mysqli_fetch_assoc($queryApplicationsData)) {
        $universityId = $row["universityId"];
        $sqlUniversityName = "SELECT * FROM universities WHERE `universityId` = '$universityId'";
        $queryUniversityName = mysqli_query($link, $sqlUniversityName);

        if (mysqli_num_rows($queryUniversityName) > 0) {
            $rowUniversityInfo = mysqli_fetch_assoc($queryUniversityName);
            $arrBoardingName[$nBoarding] = $rowUniversityInfo["universityName"];
            $arrBoardingCountry[$nBoarding] = $rowUniversityInfo["universityCountry"];
            $arrBoardingAppId[$nBoarding] = $row["applicationId"];
            $arrBoardingAppStatus[$nBoarding] = $row["appStatus"];
            $arrBoardingComission[$nBoarding] = $rowUniversityInfo["commission"];

            $nBoarding++;
        }
    }

    // for Meetings
    $sqlMeetings = "SELECT * FROM meetings WHERE `studentId` = '$studentId'";
    $queryMeetings = mysqli_query($link, $sqlMeetings);

    $nMeetings = 0;
    while ($row = mysqli_fetch_assoc($queryMeetings)) {
        $arrMeetingId[$nMeetings] = $row["meetingId"];
        $arrMeetingConsultantId[$nMeetings] = $row["consultantId"];
        $arrMeetingDate[$nMeetings] = $row['meetingDate'];
        $arrmMeetingNotes[$nMeetings] = $row['meetingNotes'];
        $nMeetings++;
    }

?>




<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Student <?php echo $dataStudent["name"]; ?></title>

    <style>
        #content {
            width: 70%;
            margin: auto;
        }
        .search-bar-name {
            background-image: url('/css/searchicon.png');
            background-position: 10px 12px;
            background-repeat: no-repeat;
            width: 100%;
            font-size: 16px;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            margin-bottom: 12px;
        }
        .search-bar-country {
            background-image: url('/css/searchicon.png');
            background-position: 10px 12px;
            background-repeat: no-repeat;
            width: 100%;
            font-size: 16px;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            margin-bottom: 12px;
        }
        .full-name {
            font-weight: bold;
        }

        .navbar {
            height: 150px;
        }

        .badge {
            /* height: 30px; */
            font-size: 15px;
            color: white;
            background-color: var(--pink) !important;
            position: absolute;
            right: 50%;
        }
        
        .fw-bold {
            font-weight: bold;
        }

        .student-info {
            font-size: 18px;
            font-weight: bold;
        }

        .title-info {
            font-weight: bold;
            color: var(--pink);
            font-size: 20px;
        }

        .info-row {
            display: inline; /* the default for span */
        }

        .statusSelect {
            width: 100px;
            height: 25px;
        }

        .comissionable-filter {
            display: flex;
            align-items: center;
            margin-bottom: 5px; /* Adjust margin as needed */
            margin-left: 3px;
        }

        label {
            padding-top: 4.5px;
            padding-left: 3px;
            font-weight: normal;
        }

    </style>
    <style>

        /* Navigation Buttons */
        .nav-buttons {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .tab-button {
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            width: 45%;
            text-align: center;
            cursor: pointer;
            border: 2px solid #007bff;
            background-color: white;
            color: #007bff;
            font-weight: bold;
        }

        .tab-button:hover {
            background: #e0e0e0;
        }

        /* Active Button (Selected) */
        .tab-button.active {
            background: #007bff;
            color: white;
        }

        /* Hide All Sections Initially */
        .content-section {
            display: none;
            text-align: center;
        }

        /* Show only the selected section */
        .visible {
            display: block;
        }

        /* Card Styles */
        .card {
            background: #e9e9e9;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            margin: 10px auto;
            text-align: center;
        }

        .card h3 {
            margin: 10px 0;
            font-size: 18px;
            color: #333;
        }

        .card p {
            color: #555;
            font-size: 14px;
            margin: 5px 0;
        }

        /* Buttons */
        .tab-button {
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            cursor: pointer;
            margin: 5px;
            font-size: 14px;
        }

        /* Edit Button */
        .edit-btn {
            background: #007bff;
            color: #fff;
        }

        .edit-btn:hover {
            background: #0056b3;
        }

        /* View Notes Button */
        .view-notes-btn {
            background: #28a745;
            color: #fff;
        }

        .view-notes-btn:hover {
            background: #218838;
        }

        .disabled:hover {
            cursor: not-allowed;

        }
    </style>
  </head>


  
  
  <?php include("navbar.php"); ?>

  <div id = "content">
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>


    <p class = "student-info"> <span class = "title-info"> Student Name: </span> <?php echo $dataStudent['name']; ?> </p>
    <p class = "student-info"> <span class = "title-info"> Student's Email: </span> <?php echo $dataStudent['email']; ?> </p>
    <p class = "student-info"> <span class = "title-info"> Parent's Email: </span> <?php echo $dataStudent['parentEmail']; ?> </p>

    <p class = "student-info"> <span class = "title-info"> HighSchool: </span> <?php echo $dataStudent['highSchool']; ?> </p>
    <p class = "student-info"> <span class = "title-info"> Phone number: </span> <?php echo $dataStudent['phoneNumber']; ?> </p>
    <p class = "student-info"> <span class = "title-info"> Grade: </span> <?php echo $dataStudent['grade']; ?> </p>
    <p class = "student-info"> <span class = "title-info"> Sign Grade: </span> <?php echo $dataStudent['signGrade']; ?> </p>
    <p class = "student-info"> <span class = "title-info"> Package Type: </span> <?php echo $dataStudent['packageType']; ?> </p>
    <p class = "student-info"> <span class = "title-info"> Consultant: </span> <?php echo $dataStudent['consultantName']; ?> </p>

    <a href = <?php echo "editStudent.php?studentId=".$studentId; ?> > <button class = "btn btn-primary"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
  <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
</svg> Edit student info </button> </a>

<br>
<br>

<a href="<?php echo $dataStudent["driveLink"]; ?>" target = "__blank"> 
  <button class="btn btn-primary">
    Drive Link Student
  </button>
</a>

    
    <br>
    <br>

    <a href = "removeStudent.php?studentId=<?php echo $studentId; ?>"> <button class = "btn btn-danger"> <i class="fa-solid fa-minus"></i> Remove Student </button> </a>
    <br>
    <br>
    
    <div class="nav-buttons">
            <button id="meetings-btn" class="tab-button" onclick="showSection('meetings-section', 'meetings-btn')">Meetings</button>
            <button id="university-applications-btn" class="tab-button active" onclick="showSection('university-applications-section', 'university-applications-btn')">University Applications</button>
            <button id="summer-applications-btn" class="tab-button" onclick="showSection('summer-applications-section', 'summer-applications-btn')">Summer School Applications</button>
            <button id="boarding-applications-btn" class="tab-button" onclick="showSection('boarding-applications-section', 'boarding-applications-btn')">Boarding School Applications</button>
    </div>

    <!-- Meetings -->
    <div id="meetings-section" class="content-section">
    <a href = "addMeeting.php?studentId=<?php echo $studentId; ?>"> <button class = "btn btn-primary"> <i class="fa-solid fa-plus"></i> Add meetings </button> </a>
        <br>
        <br>

        <h1 style = "float: left;"> Student's Meetings </h1>
        <br>
        <br>
        <br>
        <br>

        <ol class="list-group list-group-numbered" id = "meetings-list">
            <?php
            for ($i = 0; $i < $nMeetings; $i++) { ?>
                <div class = "meeting">
                    <li class="list-group-item d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">
                            <div class="fw-bold">Meeting on <?php echo $arrMeetingDate[$i]; ?></div>
                        </div>
                        <div>
                            <a href = "meeting.php?meetingId=<?php echo $arrMeetingId[$i]; ?>"> <button type="button" class="btn btn-primary">View details</button> </a>
                        </div>
                    </li>
                </div>
            <?php
            }
            ?>
        </ol>

        <br>
    </div>

    <!-- Universities --> 
    <div id="university-applications-section" class="content-section visible">

        <a href = "addApplicationStudent.php?institutionType=0&studentId=<?php echo $studentId; ?>"> <button class = "btn btn-primary"> <i class="fa-solid fa-plus"></i> Add University application </button> </a>
        <br>
        <br>

        <h1 style = "float: left;"> University Applications</h1>
        <input type="text" class = "search-bar-name" id="search-bar-university-name" onkeyup="searchFunctionUniversities()" placeholder="Search for university's name.." title="Type in a name">
        <input type="text" class = "search-bar-country" id="search-bar-university-country" onkeyup="searchFunctionUniversities()" placeholder="Search for university's country.." title="Type in a name">

        <div class = "comissionable-filter">
            <input checked onchange = "searchFunctionUniversities()" type="checkbox" id="commissionable-university" name="commisionable-university" value="1">
            <label for="commissionable-university"> Commissionable Universities</label>
        </div>

        <div class = "comissionable-filter">
            <input checked onchange = "searchFunctionUniversities()" type="checkbox" id="non-commissionable-university" name="non-commisionable-university" value="0">
            <label for="non-commissionable-university"> Non-commissionable Universities</label>
        </div>

        <ol class="list-group list-group-numbered" id = "university-applications-list">
            <?php
            for ($i = 0; $i < $nUniversities; $i++) { ?>
                <div class = "university-application">
                    <li class="list-group-item d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">
                            <div class="fw-bold university-name"><?php echo $arrUniversityName[$i]; ?></div>
                            <p class = "university-country"> <?php echo $arrUniversityCountry[$i]; ?> </p>
                            <?php
                            if (trim($arrUniversityAppStatus[$i]) == "Accepted") { ?>
                                <p> Scholarship: <span class = "university-commission">  <b><?php echo $arrUniversityScholarship[$i]; ?></b> </span> </p>
                            <?php } ?>
                            <p> Comission: <span class = "university-commission">  <b><?php echo $arrUniversityComission[$i]; ?> </b></span> </p>


                        </div>
                        <span class="badge bg-primary rounded-pill" style = "background-color: <?php echo getStatusColor($arrUniversityAppStatus[$i]); ?> !important;"> <?php echo $arrUniversityAppStatus[$i]; ?></span>
                        <div>
                            <a href = "application.php?applicationId=<?php echo $arrUniversityAppId[$i]; ?>"> <button type="button" class="btn btn-primary">View details</button> </a>
                        </div>
                    </li>
                </div>
            <?php
            }
            ?>
        </ol>

        <br>
    </div>

    <!-- Summer Schools --> 
    <div id="summer-applications-section" class="content-section">
        <a href = "addApplicationStudent.php?institutionType=1&studentId=<?php echo $studentId; ?>"> <button class = "btn btn-primary"> <i class="fa-solid fa-plus"></i> Add Summer School application </button> </a>
        <br>
        <br>

        <h1 style = "float: left;"> Summer School Applications</h1>
        <input type="text" class = "search-bar-name" id="search-bar-summer-name" onkeyup="searchFunctionSummer()" placeholder="Search for summer school's name.." title="Type in a name">
        <input type="text" class = "search-bar-country" id="search-bar-summer-country" onkeyup="searchFunctionSummer()" placeholder="Search for summer school's country.." title="Type in a name">

        <div class = "comissionable-filter">
            <input checked onchange = "searchFunctionSummer()" type="checkbox" id="commissionable-summer" name="commisionable-summer" value="1">
            <label for="commissionable-summer"> Commissionable Schools</label>
        </div>

        <div class = "comissionable-filter">
            <input checked onchange = "searchFunctionSummer()" type="checkbox" id="non-commissionable-summer" name="non-commisionable-summer" value="0">
            <label for="non-commissionable-summer"> Non-commissionable Schools</label>
        </div>

        <ol class="list-group list-group-numbered" id = "summer-applications-list">
            <?php
            for ($i = 0; $i < $nSummer; $i++) { ?>
                <div class = "summer-application">
                    <li class="list-group-item d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">
                            <div class="fw-bold summer-name"><?php echo $arrSummerName[$i]; ?></div>
                            <p class = "summer-country"> <?php echo $arrSummerCountry[$i]; ?> </p>
                            <p> Comission: <span class = "summer-commission">  <?php echo $arrSummerComission[$i]; ?> </span> </p>

                        </div>
                        <span class="badge bg-primary rounded-pill" style = "background-color: <?php echo getStatusColor($arrSummerAppStatus[$i]); ?> !important;"> <?php echo $arrSummerAppStatus[$i]; ?></span>
                        <div>
                            <a href = "application.php?applicationId=<?php echo $arrSummerAppId[$i]; ?>"> <button type="button" class="btn btn-primary">View details</button> </a>
                        </div>
                    </li>
                </div>
            <?php
            }
            ?>
        </ol>

        <br>
    </div>

    <!-- Boarding Schools --> 
    <div id="boarding-applications-section" class="content-section">
        <a href = "addApplicationStudent.php?institutionType=2&studentId=<?php echo $studentId; ?>"> <button class = "btn btn-primary"> <i class="fa-solid fa-plus"></i> Add Boarding School application </button> </a>
        <br>
        <br>

        <h1 style = "float: left;"> Boarding School Applications</h1>
        <input type="text" class = "search-bar-name" id="search-bar-boarding-name" onkeyup="searchFunctionBoarding()" placeholder="Search for boarding school's name.." title="Type in a name">
        <input type="text" class = "search-bar-country" id="search-bar-boarding-country" onkeyup="searchFunctionBoarding()" placeholder="Search for boarding school's country.." title="Type in a name">

        <div class = "comissionable-filter">
            <input checked onchange = "searchFunctionBoarding()" type="checkbox" id="commissionable-boarding" name="commisionable-boarding" value="1">
            <label for="commissionable-boarding"> Commissionable Schools</label>
        </div>

        <div class = "comissionable-filter">
            <input checked onchange = "searchFunctionBoarding()" type="checkbox" id="non-commissionable-boarding" name="non-commisionable-boarding" value="0">
            <label for="non-commissionable-boarding"> Non-commissionable Schools</label>
        </div>

        <ol class="list-group list-group-numbered" id = "boarding-applications-list">
            <?php
            for ($i = 0; $i < $nBoarding; $i++) { ?>
                <div class = "boarding-application">
                    <li class="list-group-item d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">
                            <div class="fw-bold boarding-name"><?php echo $arrBoardingName[$i]; ?></div>
                            <p class = "boarding-country"> <?php echo $arrBoardingCountry[$i]; ?> </p>
                            <p> Comission: <span class = "boarding-commission">  <?php echo $arrBoardingComission[$i]; ?> </span> </p>

                        </div>
                        <span class="badge bg-primary rounded-pill" style = "background-color: <?php echo getStatusColor($arrBoardingAppStatus[$i]); ?> !important;"> <?php echo $arrBoardingAppStatus[$i]; ?></span>
                        <div>
                            <a href = "application.php?applicationId=<?php echo $arrBoardingAppId[$i]; ?>"> <button type="button" class="btn btn-primary">View details</button> </a>
                        </div>
                    </li>
                </div>
            <?php
            }
            ?>
        </ol>

        <br>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script>
        function showSection(sectionId, buttonId) {
            // Hide all sections


            document.getElementById('university-applications-section').classList.remove('visible');
            document.getElementById('summer-applications-section').classList.remove('visible');
            document.getElementById('boarding-applications-section').classList.remove('visible');
            document.getElementById('meetings-section').classList.remove('visible');

            // Show the selected section
            document.getElementById(sectionId).classList.add('visible');


            if (document.getElementById('meetings-btn').classList.contains('active')) {
                document.getElementById('meetings-btn').classList.remove('active');
                // console.log("Meetings era activ");
            }

            if (document.getElementById('university-applications-btn').classList.contains('active')) {
                document.getElementById('university-applications-btn').classList.remove('active');
                // console.log("Univ era activ");
            }

            if (document.getElementById('summer-applications-btn').classList.contains('active')) {
                document.getElementById('summer-applications-btn').classList.remove('active');
                // console.log("Summer era activ");
            }
            
            if (document.getElementById('boarding-applications-btn').classList.contains('active')) {
                document.getElementById('boarding-applications-btn').classList.remove('active');
                // console.log("Boarding era activ");
            }

            activeButton = document.getElementById(buttonId);
            activeButton.classList.add('active');
        }
    </script>


<script>
        function searchFunctionUniversities() {
            var input, filter, ul, li, a, i, txtValue, countDisplay;
            inputName = document.getElementById("search-bar-university-name");
            inputCountry = document.getElementById("search-bar-university-country");
            inputCheckbox1 = document.getElementById("commissionable-university");
            inputCheckbox2 = document.getElementById("non-commissionable-university");


            filterName = inputName.value.toUpperCase();
            filterCountry = inputCountry.value.toUpperCase();
            checkbox1 = inputCheckbox1.checked;
            checkbox2 = inputCheckbox2.checked;


            list = document.getElementById("university-applications-list");
            universities = list.getElementsByClassName("university-application");
            countDisplay = 0;

            for (i = 0; i < universities.length; i++) {
                name = universities[i].getElementsByClassName("university-name")[0].innerHTML;
                country = universities[i].getElementsByClassName("university-country")[0].innerHTML;
                commission = universities[i].getElementsByClassName("university-commission")[0].innerHTML;
                
                if (name.toUpperCase().indexOf(filterName) > -1 && country.toUpperCase().indexOf(filterCountry) > -1 && ((commission > 0 && checkbox1) || (commission == 0 && checkbox2))) {
                    universities[i].style.display = "";
                    countDisplay++;
                } else {
                    universities[i].style.display = "none";
                }                


            }

            document.getElementsByClassName("search-count")[0].innerHTML = countDisplay;

        }

        function searchFunctionSummer() {
            var input, filter, ul, li, a, i, txtValue, countDisplay;
            inputName = document.getElementById("search-bar-summer-name");
            inputCountry = document.getElementById("search-bar-summer-country");
            inputCheckbox1 = document.getElementById("commissionable-summer");
            inputCheckbox2 = document.getElementById("non-commissionable-summer");


            filterName = inputName.value.toUpperCase();
            filterCountry = inputCountry.value.toUpperCase();
            checkbox1 = inputCheckbox1.checked;
            checkbox2 = inputCheckbox2.checked;


            list = document.getElementById("summer-applications-list");
            universities = list.getElementsByClassName("summer-application");
            countDisplay = 0;

            for (i = 0; i < universities.length; i++) {
                name = universities[i].getElementsByClassName("summer-name")[0].innerHTML;
                country = universities[i].getElementsByClassName("summer-country")[0].innerHTML;
                commission = universities[i].getElementsByClassName("summer-commission")[0].innerHTML;
                
                if (name.toUpperCase().indexOf(filterName) > -1 && country.toUpperCase().indexOf(filterCountry) > -1 && ((commission > 0 && checkbox1) || (commission == 0 && checkbox2))) {
                    universities[i].style.display = "";
                    countDisplay++;
                } else {
                    universities[i].style.display = "none";
                }                


            }

            document.getElementsByClassName("search-count")[0].innerHTML = countDisplay;

        }

        function searchFunctionBoarding() {
            var input, filter, ul, li, a, i, txtValue, countDisplay;
            inputName = document.getElementById("search-bar-boarding-name");
            inputCountry = document.getElementById("search-bar-boarding-country");
            inputCheckbox1 = document.getElementById("commissionable-boarding");
            inputCheckbox2 = document.getElementById("non-commissionable-boarding");


            filterName = inputName.value.toUpperCase();
            filterCountry = inputCountry.value.toUpperCase();
            checkbox1 = inputCheckbox1.checked;
            checkbox2 = inputCheckbox2.checked;


            list = document.getElementById("boarding-applications-list");
            universities = list.getElementsByClassName("boarding-application");
            countDisplay = 0;

            for (i = 0; i < universities.length; i++) {
                name = universities[i].getElementsByClassName("boarding-name")[0].innerHTML;
                country = universities[i].getElementsByClassName("boarding-country")[0].innerHTML;
                commission = universities[i].getElementsByClassName("boarding-commission")[0].innerHTML;
                
                if (name.toUpperCase().indexOf(filterName) > -1 && country.toUpperCase().indexOf(filterCountry) > -1 && ((commission > 0 && checkbox1) || (commission == 0 && checkbox2))) {
                    universities[i].style.display = "";
                    countDisplay++;
                } else {
                    universities[i].style.display = "none";
                }                


            }

            document.getElementsByClassName("search-count")[0].innerHTML = countDisplay;

        }
</script>
</body>
</html>