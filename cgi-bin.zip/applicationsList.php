<?php
    session_start();

    if (!isset($_SESSION['type'])) {
        header("location: index.php");
        die();
    }
    else {
        $typeAccount = $_SESSION["type"];
        $userId = $_SESSION["id"];
    }

    require_once "configDatabase.php";
    
    
?>

<?php // GET DATA
    $consultants = $_GET['consultant'];

    $consultantString = "(";
    $firstElem = 0;

    foreach ($consultants as $consultant) {
        if ($firstElem > 0)
            $consultantString .= ',';
        $consultantString .= $consultant;
        $freqConsultant[$consultant] = 1;

        $firstElem += 1;
    }
    $consultantString .= ')';
    // echo $consultantString;

    if ($firstElem == 0) {
        $consultantString = "(";

        $sqlConsultants = "SELECT userId FROM users WHERE type = 0";
        $resultConsultants = mysqli_query($link, $sqlConsultants);

        $firstElem = 0;
        while ($row = mysqli_fetch_assoc($resultConsultants)) {
            if ($firstElem > 0)
                $consultantString .= ",";
            $consultantString .= $row['userId'];
            // $freqConsultant[$row['userId']] = 1;

            $firstElem += 1;
        }
        $consultantString .= ")";
    }

    $institutionType = $_GET['institution'];

    $institutionString = "('";
    $firstElem = 0;

    foreach ($institutionType as $institution) {
        if ($firstElem > 0)
            $institutionString .= "','";
        $institutionString .= $institution;
        $freqInstitution[$institution] = 1;

        $firstElem += 1;
    }
    $institutionString .= "')";

    if ($firstElem == 0) {
        $institutionString = "(0, 1, 2)";
    }

    // echo $packageString;
    // grade checkbox 
    $commissionType = $_GET['commission'];

    $commissionString = "(";
    $firstElem = 0;

    foreach ($commissionType as $commission) {
        if ($firstElem > 0)
            $commissionString .= ',';
        $commissionString .= $commission;
        $freqCommission[$commission] = 1;

        $firstElem += 1;
    }
    $commissionString .= ')';

    if ($firstElem == 0) {
        $commissionString = "(0, 1)";
    }
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <title>Applications List </title>

    <style>
        #contentStudents {
            width: 70%;
            /* float: right; */
            margin: auto;
        }
        #contentFilter {
            width: 10%;
            float: left;
            margin-left: 30px;
            margin-top: 0px;
        }
        #search-bar {
            background-image: url('/css/searchicon.png');
            background-position: 10px 12px;
            background-repeat: no-repeat;
            width: 100%;
            font-size: 16px;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            margin-bottom: 12px;
        }
        .full-name {
            font-weight: bold;
        }

        .navbar {
            height: 150px;
        }

        #content {
            display: inline;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            margin-bottom: 5px; /* Adjust margin as needed */
        }
        .checkbox-container input[type="checkbox"] {
            margin-right: 10px; /* Adjust margin as needed */
        }

        .checkboxLabel {
            padding-top: 4.5px;
            font-weight: normal;
        }

        h3 {
            border-bottom: 4px solid black;
            text-align: center;
        }

        h4 {
            border-bottom: 3px solid #ccc;
            text-align: center;
        }

        .filterPackage {
            padding-bottom: 5px;
        }

        .filterConsultants {
            padding-bottom: 5px;
        }

        .page-link {
            padding: 5px;
            text-decoration: none;
            font-size: 16px;
        }

        .pagination {
            display: inline-block;
        }

        .pagination a {
            color: black;
            float: left;
            padding: 8px 16px;
            text-decoration: none;
            border: 1px solid #ddd;
        }

        .pagination a.active {
            background-color: var(--pink);
            color: white;
            border: 1px solid var(--pink);
        }

        .pagination a:hover:not(.active) {background-color: #ddd;}

        .pagination a:first-child {
            border-top-left-radius: 5px;
            border-bottom-left-radius: 5px;
        }

        .pagination a:last-child {
            border-top-right-radius: 5px;
            border-bottom-right-radius: 5px;
        }

        .pagination a.disabled {
            pointer-events: none;
        }

    </style>
    
  </head>

  
  <?php include("navbar.php"); ?>

  <br>
    <br>
    <br>
    <br>
    <br>
        
  <div id = "content">
    <div id = "contentFilter" >
        <h3>Filters</h3>
        <br>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="GET" id = "filters-form"> 
        <?php
        if ($typeAccount == 1) { 
        ?>
        <div class = "filterConsultants">
            <h4> Consultants </h4>
            <?php 
                $sql = "SELECT userId, fullName FROM users WHERE type = 0"; // iau consultantii
                $result = mysqli_query($link, $sql);
                $nConsultant = 0;
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="checkbox-container">

                    <?php
                        if ($freqConsultant[$row['userId']] == 1) {
                            echo "<input checked type='checkbox' id='checkbox" . $row['userId'] . "' value='" . $row['userId'] . "' name='consultant[]' onchange='submitForm()'>";
                            echo "<label class='checkboxLabel' for='checkbox" . $row['userId'] . "'>" . $row['fullName'] . "</label>";
                        } else {
                            echo "<input type='checkbox' id='checkbox" . $row['userId'] . "' value='" . $row['userId'] . "' name='consultant[]' onchange='submitForm()'>";
                            echo "<label class='checkboxLabel' for='checkbox" . $row['userId'] . "'>" . $row['fullName'] . "</label>";
                        }
                    ?> 

                    </div> <!-- closing checkbox div -->
                    <?php
                }
            ?>

        </div>
        <?php
        }
        ?>

        <div class = "filterInstitutionType">
            <h4> Institution Type </h4>
            <div class="checkbox-container">
                <input <?php if ($freqInstitution['0'] == 1) { echo "checked";} ?> type="checkbox" id="checkboxUniversity" value="0" name="institution[]" onchange="submitForm()">
                <label class = "checkboxLabel" for="checkboxUniversity">University</label>
            </div>

            <div class="checkbox-container">
                <input <?php if ($freqInstitution['1'] == 1) { echo "checked";} ?> type="checkbox" id="checkboxSummer" value="1" name="institution[]" onchange="submitForm()">
                <label class = "checkboxLabel" for="checkboxSummer">Summer School</label>
            </div>

            <div class="checkbox-container">
                <input <?php if ($freqInstitution['2'] == 1) { echo "checked";} ?> type="checkbox" id="checkboxBoarding" value="2" name="institution[]" onchange="submitForm()">
                <label class = "checkboxLabel" for="checkboxBoarding">Boarding School</label>
            </div>
        </div>

        <div class = "filterComission">
            <h4> Commission </h4>
            <div class="checkbox-container">
                <input <?php if ($freqCommission[1] == 1) { echo "checked";} ?> type="checkbox" id="checkboxComissionable" value="1" name="commission[]" onchange="submitForm()">
                <label class = "checkboxLabel" for="checkboxComissionable">Comissionable</label>
            </div>

            <div class="checkbox-container">
                <input <?php if ($freqCommission[0] == 1) { echo "checked";} ?> type="checkbox" id="checkboxNon-Comissionable" value="0" name="commission[]" onchange="submitForm()">
                <label class = "checkboxLabel" for="checkboxNon-Comissionable">Non-Comissionable</label>
            </div>
        </div>

        
        <input type="button" onclick="location.href='https://internconsultancy.younichoice.com/applicationsList.php';" value="Reset" />
        <br>
        <br>
        <input type="submit">
        </form>
    </div>  
    <div id = "contentStudents">
        <h1 style = "float: left;"> Applications List</h1>
        <br>
        <br>
        <br>
        <br>


        <!-- <input type="text" id="search-bar" onkeyup="searchFunction()" placeholder="Search for students.." title="Type in a name"> -->
        <ol id = "students-list" class="list-group list-group-numbered">
            <?php
            if ($typeAccount == 1) {
                $sqlApplication = "SELECT 
                    sd.consultantId,
                    sd.consultantName,
                    sd.name AS studentName,
                    u.commission AS commission,
                    u.universityCountry AS universityCountry,
                    u.universityName AS universityName,
                    u.institutionType AS institutionType,
                    aps.appStatus AS appStatus,
                    aps.applicationId AS applicationId
                FROM 
                    applicationStatus aps
                INNER JOIN 
                    studentData sd ON aps.studentId = sd.studentId
                INNER JOIN 
                    universities u ON aps.universityId = u.universityId
                WHERE 
                    sd.consultantId IN " . $consultantString . "
                    AND u.institutionType IN " . $institutionString . "
                    AND u.commission IN " . $commissionString .  ";";
            }
            else {
                $sqlApplication = "SELECT 
                    sd.consultantId,
                    sd.consultantName,
                    sd.name AS studentName,
                    u.commission AS commission,
                    u.universityCountry AS universityCountry,
                    u.universityName AS universityName,
                    u.institutionType AS institutionType,
                    aps.appStatus AS appStatus,
                    aps.applicationId AS applicationId
                FROM 
                    applicationStatus aps
                INNER JOIN 
                    studentData sd ON aps.studentId = sd.studentId
                INNER JOIN 
                    universities u ON aps.universityId = u.universityId
                WHERE 
                    sd.consultantId = '$userId'
                    AND sd.consultantId IN " . $consultantString . "
                    AND u.institutionType IN " . $institutionString . "
                    AND u.commission IN " . $commissionString .  ";";
            }
            $queryApplication = mysqli_query($link, $sqlApplication);

            $noApplications = mysqli_num_rows($queryApplication);

            if (!isset($noApplications))
                $noApplications = 0;

            ?> <p style = "font-weight: bold;"> There are <span class = "search-count"><?php echo $noApplications; ?></span> applications in your search </p> <?php
            while ($row = mysqli_fetch_assoc($queryApplication)) {
              ?>
                <div class = "student">
                    <li class="list-group-item d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">
                        <div class="full-name">Application from <?php echo $row['studentName'] . " to " . $row['universityName'] . "(" . $row['universityCountry'] . ")"; ?></div>
                        <br>
                        <p class = "consultant"> <span style = "font-weight: bold"> Consultant: </span> <?php echo $row['consultantName'];?> </p>
                       
                        
                        </div>
                        <?php $urlApplication = "application.php?applicationId=" . $row['applicationId'];?>
                        <a href = <?php echo $urlApplication;?> > <button type="button" class="btn btn-primary">View details</button> </a>
                    </li>
                </div>
              <?php      
            }
            ?>

        </ol>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
        function searchFunction() {
            var input, filter, ul, li, a, i, txtValue;
            input = document.getElementById("search-bar");
            filter = input.value.toUpperCase();
            list = document.getElementById("students-list");
            students = list.getElementsByClassName("student");
            countDisplay = 0;
            for (i = 0; i < students.length; i++) {
                name1 = students[i].getElementsByClassName("full-name")[0].innerHTML;
                name2 = students[i].getElementsByClassName("highSchool")[0].innerHTML;
                name3 = students[i].getElementsByClassName("consultant")[0].innerHTML;

                name = name1 + name2 + name3;
                if (name.toUpperCase().indexOf(filter) > -1) {
                    students[i].style.display = "";
                    countDisplay++;
                } else {
                    students[i].style.display = "none";
                }
            }
            document.getElementsByClassName("search-count")[0].innerHTML = countDisplay;
        }

        function submitForm() {
            document.getElementById('filters-form').submit();
        }
    </script>
</body>
</html>